import SignUp from "../pageobject/Signup"
describe('SignUp', () => {

  beforeEach(function(){
    cy.fixture('signup').then(function(data){
      this.data = data
   }) 
})

beforeEach(function(){

   cy.visit(this.data.url);
   cy.title().should('be.equal','PickNDeal');
   cy.contains('Sign Up').click();

})

var locator = new SignUp();

  it('Verify that user is able to navigate on signup page.', function() {
    cy.contains('Sign Up').should('be.visible');
  })

  it('Verify that user is able to see two profile options.',()=>{
    cy.get(locator.profile1).should('be.visible').should('contain.text', 'Retailer');
    cy.get(locator.profile2).should('be.visible').should('contain.text', 'Supplier');

  })

  it('Verify that user is able to select profile.',()=>{
    cy.get(locator.profile1).should('be.visible');
    cy.get(locator.profile2).should('be.visible');
    cy.get(locator.profile2).click();
    cy.get(locator.profile2).should('have.css', 'background-color', '#2e42e2'); 
    cy.get(locator.profile1).click(); 

  })

  it('Verify that user is able to see all the fields are present',()=>{
    cy.get(locator.firstname).should('be.visible');
    cy.get(locator.lastname).should('be.visible');
    cy.get(locator.email).should('be.visible');
    cy.get(locator.phoneNo).should('be.visible');
    cy.get(locator.password).should('be.visible');
    cy.get(locator.cPassword).should('be.visible');
  })

  it('Verify that user is able to type text under First Name input field.',function(){
    cy.get(locator.firstname).should('be.visible');
    cy.get(locator.firstname).type(this.data.firstname);
    cy.get(locator.firstname).invoke('text').then((text) => {
      expect(text).to.be.equal(this.data.firstname)
      cy.log(text)
    })
    
  })

  it('Verify that user is able to type text under Last Name input field.',function(){
    cy.get(locator.lastname).should('be.visible');
    cy.get(locator.lastname).type(this.data.lastname);
    cy.get(locator.lastname).invoke('text').then((text) => {
      expect(text).to.be.equal(this.data.lastname)
      cy.log(text)

    })
    
  })

  it('Verify that user is able to type text under Email Address input field.',function(){
    cy.get(locator.email).should('be.visible');
    cy.get(locator.email).type(this.data.email);
    
  })

  it('Verify that user is able to type input data under Phone Number field.',function(){
    cy.get(locator.phoneNo).should('be.visible');
    cy.get(locator.phoneNo).type(this.data.phoneNo);
    
  })

  it('Verify that user is able to type input data under Password field.',function(){
    cy.get(locator.password).should('be.visible');
    cy.get(locator.password).type(this.data.password);
    
  })

  it('Verify that user is able to type input data under Confirm Password field.',function(){
    cy.get(locator.cPassword).should('be.visible');
    cy.get(locator.cPassword).type(this.data.password);

    
  })

  it('TC_11 TC_012 TC_014',function(){
    cy.get(locator.firstname).type(this.data.firstname);
    cy.get(locator.lastname).type(this.data.lastname);
    cy.get(locator.email).type(this.data.email);
    cy.get(locator.phoneNo).type(this.data.phoneNo);
    cy.get(locator.password).type(this.data.password);
    cy.get(locator.cPassword).type(this.data.password);
    cy.get(locator.signUpButton).should('be.visible');
    cy.get(locator.signUpButton).click();
    cy.contains('Sign In').should('be.visible');
    cy.get(locator.registeredMessage).should('contain.text', this.data.registeredSuccessful);
    
  })

  it('TC_014 TC_015 TC_016',()=>{
    cy.get(locator.loginLink).should('contain.text', 'Have an account? ');
    cy.get(locator.loginLink).should('contain.text', 'Sign In');
    cy.get(locator.loginLink).click();
    cy.contains('Sign In').should('be.visible');

  })

})
